# MongoDB Go Driver Experimental Packages

**WARNING: THESE PACKAGES ARE EXPERIMENTAL AND MAY BE MODIFIED OR REMOVED
WITHOUT NOTICE.**

This directory contains packages intended only for internal use. They are made
available to facilitate use cases that require access to internal MongoDB driver
functionality and state. The APIs of these packages are not stable and there is
no backward compatibility guarantee. Use with extreme caution!
